#include "pch.h"
#include <iostream>
#include <random>
#include <algorithm>

using namespace std;

void bubble_sort(int* array, int sz) {
    for (int i = 0; i < sz; i++)
        for (int j = i; j < sz; j++) {
            if (array[i] > array[j]) 
                swap(array[i], array[j]);
        }
}

void selection_sort(int* array, int sz) {
    for (int i = 0; i < sz; i++) {
        int min_loc = i;
        for (int j = i + 1; j < sz; j++) {
            if (array[j] < array[min_loc]) min_loc = j;
        }
        if (array[min_loc] < array[i]) 
            swap(array[i], array[min_loc]);
    }
}

void quicksort(int* a, int from, int to) {
    if (from >= to) return;
    int pivot = a[from], i = from, j = to;
    while (i < j) {
        do i++; while (a[i] < pivot);
        do j--; while (a[j] > pivot);
        if (i < j) swap(a[i], a[j]);
    }
    swap(a[from], a[j]);
    quicksort(a, from, j);
    quicksort(a, j + 1, to);
}

void merge(int* a, int from, int mid, int to)
{
    int n = to - from + 1;
    int* b = new int[n];
    int i1 = from;
    int i2 = mid + 1;
    int j = 0;
    while (i1 <= mid && i2 <= to) {
        if (a[i1] < a[i2]) {
            b[j] = a[i1];
            i1++;
        }
        else {
            b[j] = a[i2];
            i2++;
        }
        j++;
    }
    while (i1 <= mid) {
        b[j] = a[i1];
        i1++;
        j++;
    }
    while (i2 <= to) {
        b[j] = a[i2];
        i2++;
        j++;
    }
    for (j = 0; j < n; j++) {
        a[from + j] = b[j];
    }
    delete[] b;
}

void merge_sort(int* array, int from, int to) {
    if (from == to) return;
    int mid = (from + to) / 2;
    merge_sort(array, from, mid);
    merge_sort(array, mid + 1, to);
    merge(array, from, mid, to);
}

TEST(SHORT, BUBBLE_SORT) {
    int array[5] = { 5, 3, 2, 1, 4 };
    int sorted[5] = { 1, 2, 3, 4, 5 };
    bubble_sort(array, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(SHORT, SELECTION_SORT) {
    int array[5] = { 5, 3, 2, 1, 4 };
    int sorted[5] = { 1, 2, 3, 4, 5 };
    selection_sort(array, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(SHORT, QUICKSORT) {
    int array[5] = { 5, 3, 2, 1, 4 };
    int sorted[5] = { 1, 2, 3, 4, 5 };
    quicksort(array, 0, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(SHORT, MERGE_SORT) {
    int array[5] = { 5, 3, 2, 1, 4 };
    int sorted[5] = { 1, 2, 3, 4, 5 };
    quicksort(array, 0, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(LONG, BUBBLE_SORT) {
    int array[100], sorted[100];
    for (int i = 0; i < 100; i++) {
        array[i] = sorted[i] = i;
    }
    random_shuffle(std::begin(array), std::end(array));
    bubble_sort(array, 100);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(LONG, SELECTION_SORT) {
    int array[100], sorted[100];
    for (int i = 0; i < 100; i++) {
        array[i] = sorted[i] = i;
    }
    selection_sort(array, 100);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(LONG, QUICKSORT) {
    int array[100], sorted[100];
    for (int i = 0; i < 100; i++) {
        array[i] = sorted[i] = i;
    }
    quicksort(array, 0, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}

TEST(LONG, MERGE_SORT) {
    int array[100], sorted[100];
    for (int i = 0; i < 100; i++) {
        array[i] = sorted[i] = i;
    }
    quicksort(array, 0, 5);
    EXPECT_TRUE(0 == std::memcmp(array, sorted, sizeof(array)));
}